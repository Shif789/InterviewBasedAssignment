package in.ineuron;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import in.ineuron.model.Student;
import in.ineuron.util.HibernateUtil;

public class App {
	private static Session session = null;
	private static Transaction transaction = null;
	private static boolean flag = false;
	private static Integer id = null;

	public static void main(String[] args) {
		int option = 0;
		try {
			if (session == null) {
				session = HibernateUtil.getSession();

				Scanner scan = new Scanner(System.in);
				System.out.print("Press 1 for update operation/n Press 2 for search operation: ");
				option = scan.nextInt();

				if (option == 1)
					updateOperation();

				else if (option == 2)
					searchOperation();
				else
					System.out.println("Enter a valid number from the option given!");

				scan.close();
			}
		} catch (HibernateException e) {
			e.printStackTrace();
			flag = false;
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		} finally {
			if (option == 1)
				transactionActivites();

			// closing resources
			HibernateUtil.closeSession();
			HibernateUtil.closeSessionFactory();
		}
	}

	public static void updateOperation() throws IOException {

		if (session != null) {
			transaction = session.beginTransaction();
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

			System.out.print("Enter the student id for updation: ");
			id = Integer.parseInt(bufferedReader.readLine());

			Student student = session.get(Student.class, id);

			if (student != null) {
				System.out.print("Student name is: " + student.getSname() + ", Enter the updated student name: ");
				String name = bufferedReader.readLine();
				System.out.print(
						"Student address is: " + student.getSaddress() + ", Enter the updated student address: ");
				String address = bufferedReader.readLine();
				System.out.print("Student age is: " + student.getSage() + ", Enter the updated student age: ");
				String age = bufferedReader.readLine();

				if (transaction != null) {
					if (!name.equals(""))
						student.setSname(name);

					if (!address.equals(""))
						student.setSaddress(address);

					if (!age.equals(""))
						student.setSage(Integer.parseInt(age));

					session.update(student);
					flag = true;
				}
			}
			bufferedReader.close();
		}
	}

	public static void transactionActivites() {
		if (flag) {
			transaction.commit();
			System.out.println("Student record updated to database with id: " + id);
		} else {
			transaction.rollback();
			System.out.println("Student record failed to update to database with id: " + id);
		}
	}

	public static void searchOperation() {
		if (session != null) {
			Scanner scanner = new Scanner(System.in);
			System.out.print("Enter the student id: ");
			id = scanner.nextInt();
			Student student = session.get(Student.class, id);

			if (student != null)
				System.out.println(student);

			else
				System.out.println("Student record not found with id: " + id);

			scanner.close();
		}
	}
}
