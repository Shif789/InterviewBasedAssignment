package in.ineuron;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment24ApplicationTests {

	@Test
	void contextLoads() {
	}

}
