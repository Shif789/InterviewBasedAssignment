package in.ineuron.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ineuron.model.Student;
import in.ineuron.service.IStudentService;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/api/student")
public class StudentRestController {

	@Autowired
	private IStudentService service;

	@PostMapping(value = "/save")
	@ApiOperation("To perform insertion")
	public ResponseEntity<String> insertStudent(@RequestBody Student student) {
		String responseBody = service.addStudent(student);

		return new ResponseEntity<String>(responseBody, HttpStatus.CREATED);
	}

	@PutMapping(value = "/update")
	@ApiOperation("To perform updation")
	public ResponseEntity<String> updateStudent(@RequestBody Student student) {
		String responseBody = service.updateStudent(student);

		return new ResponseEntity<String>(responseBody, HttpStatus.OK);
	}

	@DeleteMapping(value = "/delete/{id}")
	@ApiOperation("To perform deletion")
	public ResponseEntity<String> deleteStudentById(@PathVariable Integer id) {
		String responseBody = service.removeStudentById(id);

		return new ResponseEntity<String>(responseBody, HttpStatus.OK);
	}

	@GetMapping(value = "/find/{id}")
	@ApiOperation("To perform search by id")
	public ResponseEntity<?> searchStudentById(@PathVariable Integer id) {
		Student student = service.fetchStudentById(id);
		if (student != null)
			return new ResponseEntity<Student>(student, HttpStatus.OK);

		return new ResponseEntity<String>("Student record not found with id: " + id, HttpStatus.NOT_FOUND);
	}

	@GetMapping(value = "/findAll")
	@ApiOperation("To perform search all")
	public ResponseEntity<?> searchAllStudents() {
		List<Student> allStudents = service.fetchAllStudents();

		return new ResponseEntity<>(allStudents != null ? allStudents : "Student Table is empty", HttpStatus.OK);
	}
}
