package in.ineuron.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.dao.IStudentRepository;
import in.ineuron.model.Student;

@Service
public class StudentServiceImpl implements IStudentService {

	@Autowired
	private IStudentRepository repository;

	@Override
	public String addStudent(Student student) {
		Student savedStudent = null;
		savedStudent = repository.save(student);

		return savedStudent != null ? "Student saved with id: " + savedStudent.getId() : "Student insertion failed!";
	}

	@Override
	public String updateStudent(Student student) {
		boolean exists = repository.existsById(student.getId());
		if (exists) {
			Student updatedStudent = repository.save(student);
			return updatedStudent != null ? "Student record updated with id: " + updatedStudent.getId()
					: "Student record updation failed with id: " + student.getId();
		}
		return "Student record not found with id: " + student.getId();
	}

	@Override
	public String removeStudentById(Integer id) {
		boolean exists = repository.existsById(id);
		if (exists) {
			repository.deleteById(id);
			return "Student record deleted successfully with id: "+id;
		}
		
		return "Student record not found for deletion with id: "+id;
	}

	@Override
	public Student fetchStudentById(Integer id) {
		Optional<Student> optional = repository.findById(id);
		if (optional.isPresent())
			return optional.get();
		
		return null;
	}

	@Override
	public List<Student> fetchAllStudents() {
		
		return repository.findAll();
	}

}
