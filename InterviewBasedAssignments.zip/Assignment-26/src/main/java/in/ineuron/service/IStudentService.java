package in.ineuron.service;

import java.util.List;

import in.ineuron.model.Student;

public interface IStudentService {

	String addStudent(Student student);

	String updateStudent(Student student);

	String removeStudentById(Integer id);

	Student fetchStudentById(Integer id);

	List<Student> fetchAllStudents();
}
