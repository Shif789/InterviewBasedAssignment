package in.ineuron.restcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ineuron.model.Student;
import in.ineuron.service.IStudentService;

@RestController
@RequestMapping("/api/student")
public class StudentRestController {

	@Autowired
	private IStudentService service;

	@GetMapping(value = "/find/{id}")
	public ResponseEntity<?> getStudentById(@PathVariable Integer id) {
		Student student = service.fetchStudentById(id);
		if (student != null)
			return new ResponseEntity<Student>(student, HttpStatus.OK);

		return new ResponseEntity<String>("Student record not found with id: " + id, HttpStatus.NOT_FOUND);
	}
}
