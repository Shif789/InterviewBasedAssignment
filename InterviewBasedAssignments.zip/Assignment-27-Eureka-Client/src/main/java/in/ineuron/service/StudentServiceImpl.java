package in.ineuron.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.dao.IStudentRepository;
import in.ineuron.model.Student;

@Service
public class StudentServiceImpl implements IStudentService {

	@Autowired
	private IStudentRepository repository;

	@Override
	public Student fetchStudentById(Integer id) {
		Optional<Student> optional = repository.findById(id);
		if (optional.isPresent())
			return optional.get();

		return null;
	}

}
