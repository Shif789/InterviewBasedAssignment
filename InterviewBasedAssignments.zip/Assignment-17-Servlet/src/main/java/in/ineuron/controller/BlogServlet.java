package in.ineuron.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.ineuron.model.BlogDao;

@WebServlet(urlPatterns = "/blog", loadOnStartup = 10, initParams = {
		@WebInitParam(name = "url", value = "jdbc:mysql://localhost:3306/ineuron"),
		@WebInitParam(name = "username", value = "root"), @WebInitParam(name = "password", value = "123456789") })
public class BlogServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static Connection connection = null;
	private BlogDao dao;
	static {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Driver (class file) loaded successfully...");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	public static Connection getConnection() {
		return connection;
	}

	@Override
	public void init() throws ServletException {
		System.out.println("Config object created and got the values from config obj....\n\n");
		String url = getInitParameter("url");
		String username = getInitParameter("username");
		String password = getInitParameter("password");
		System.out.println(url);
		System.out.println(username);
		System.out.println(password);

		try {
			connection = DriverManager.getConnection(url, username, password);
			if (connection != null) {
				System.out.println("Connection established successfully...");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String id = request.getParameter("blogId");

		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		try {
			preparedStatement = connection.prepareStatement("SELECT id,title,description,content FROM blog WHERE id=?");
			if (preparedStatement != null) {
				preparedStatement.setInt(1, Integer.parseInt(id));
				resultSet = preparedStatement.executeQuery();

				if (resultSet != null) {
					resultSet.next();
					request.setAttribute("bid", resultSet.getInt(1));
					request.setAttribute("bTitle", resultSet.getString(2));
					request.setAttribute("bDescription", resultSet.getString(3));
					request.setAttribute("bContent", resultSet.getString(4));

					RequestDispatcher requestDispatcher = request.getRequestDispatcher("./disp.jsp");
					requestDispatcher.forward(request, response);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			/*
			 * try { resultSet.close(); preparedStatement.close(); connection.close(); }
			 * catch (SQLException e) { e.printStackTrace(); }
			 */
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String blogTitle = request.getParameter("title");
		String blogDescription = request.getParameter("description");
		String blogContent = request.getParameter("content");

		dao=new BlogDao();
		String insertStatus = dao.insert(blogTitle, blogDescription, blogContent);
		request.setAttribute("status",
				insertStatus);

	RequestDispatcher requestDispatcher = request.getRequestDispatcher("./index.jsp");
	requestDispatcher.forward(request, response);
	}

}
