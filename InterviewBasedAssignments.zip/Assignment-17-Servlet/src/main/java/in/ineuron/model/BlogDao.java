package in.ineuron.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import in.ineuron.controller.BlogServlet;

public class BlogDao {

	public String insert(String blogTitle, String blogDescription, String blogContent) {
		PreparedStatement preparedStatement = null;
		try {
			Connection connection = BlogServlet.getConnection();
			preparedStatement = connection
					.prepareStatement("INSERT INTO blog (title,description,content) VALUES(?,?,?)");
			if (preparedStatement != null) {
				preparedStatement.setString(1, blogTitle);
				preparedStatement.setString(2, blogDescription);
				preparedStatement.setString(3, blogContent);
				int rowsAffected = preparedStatement.executeUpdate();

				if (rowsAffected != 0)
					return "Blog post insertion successful, no. of record inserted: " + rowsAffected;
				else
					return "Blog post insertion failed, no. of record inserted: " + rowsAffected;

			}
		
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
		
		return "Internal problem";
	}
}
