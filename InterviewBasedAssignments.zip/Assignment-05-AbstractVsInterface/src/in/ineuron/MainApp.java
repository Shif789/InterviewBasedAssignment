package in.ineuron;

public class MainApp {

	public static void main(String[] args) {
		IBookMgmtService bookMgmtService = new BookMgmtServiceImpl();
		bookMgmtService.addBook();
		bookMgmtService.searchBook();
		((BookMgmtServiceImpl) bookMgmtService).deleteBook();// runtime polymorphism
		
		/* Abstract class information
		 * 
		 1.Abstract class can have both abstract and non-abstract methods.
		 2.Abstract class doesn't support multiple inheritance. extends only once
		 3.Abstract class can have final, non-final, static and non-static variables
		 4.Can provide the implementation of interface
		 5."abstract" class is used for declaration
		 6.Can extend one class but implement multiple interfaces.
		 7.Can have members like private, protected, etc.
		 */
		
		/* Interface class information
		 * 
		 1.Interface can have only abstract methods.(default and static methods are allowed in later versions)
		 2.supports multiple inheritance. extends multiple times
		 3.can have final and static variables only.
		 4.Can't provide the implementation of abstract class
		 5."interface" keyword is used for declaration
		 6.Can extend interfaces only.
		 7.By default members are public and abstract.
		 */
	}
}
