package in.ineuron;

public class BookMgmtServiceImpl extends BookMgmtServiceAb {

	@Override
	public void searchBook() {
		System.out.println("Book found...");
		
	}

	@Override
	public void deleteBook() {
		System.out.println("Book deleted successfully...");
		
	}


}
