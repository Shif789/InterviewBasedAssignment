package in.ineuron;

public abstract class BookMgmtServiceAb implements IBookMgmtService {

	@Override
	public void addBook() {
		System.out.println("Book registered successfully");
		
	}
	
	public abstract void deleteBook();

}
