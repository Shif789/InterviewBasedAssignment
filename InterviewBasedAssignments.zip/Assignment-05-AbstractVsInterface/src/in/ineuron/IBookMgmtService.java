package in.ineuron;

public interface IBookMgmtService {

	void addBook();
	void searchBook();
	
}
