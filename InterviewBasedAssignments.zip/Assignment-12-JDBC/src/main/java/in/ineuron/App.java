package in.ineuron;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import in.ineuron.util.JdbcUtil;

public class App {
	private static Connection con = null;
	private static PreparedStatement statement = null;
	private static ResultSet resultSet = null;

	public static void main(String[] args) {

		try {
			// creating connection object using DataSource object
			con = JdbcUtil.getJdbcConnection();
			System.out.println(con.getClass().getName());
			Integer option = null;
			Scanner scan = new Scanner(System.in);
			System.out.print(
					"Press 1 to find all records\nPress 2 to find record by Id\nPress 3 to insert record\n Press 4 to update record\nPress 5 to delete record: ");
			option = scan.nextInt();

			switch (option) {
			case 1:
				findAllRecords();
				break;
			case 2:
				findRecordById();
				break;
			case 3:
				insertRecord();
				break;
			case 4:
				updateRecord();
				break;
			case 5:
				deleteRecord();
				break;

			default:
				System.out.println("Enter a valid option");
				break;
			}
			
			scan.close();

		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				JdbcUtil.cleanUp(con, statement, resultSet);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public static void findAllRecords() throws SQLException {
		if (con != null) {
			statement = con.prepareStatement("SELECT id,name,age,address FROM students");
		}
		if (statement != null) {
			resultSet = statement.executeQuery();
		}
		if (resultSet != null) {
			System.out.println("Id\tName\tAge\tAddress");
			while (resultSet.next()) {
				System.out.println(resultSet.getInt(1) + "\t" + resultSet.getString(2) + "\t" + resultSet.getInt(3)
						+ "\t" + resultSet.getString(4));
			}
		}
	}

	public static void findRecordById() throws SQLException {
		Integer id = 1;
		
		if (con != null) {
			statement = con.prepareStatement("SELECT id,name,age,address FROM students WHERE id=?");
			try (Scanner scanner = new Scanner(System.in)) {
				System.out.print("Enter student id: ");
				id = scanner.nextInt();
			}
		}
		if (statement != null) {
			statement.setInt(1, id);
			resultSet = statement.executeQuery();
		}
		if (resultSet != null) {
			System.out.println("Id\tName\tAge\tAddress");
			while (resultSet.next()) {
				System.out.println(resultSet.getInt(1) + "\t" + resultSet.getString(2) + "\t" + resultSet.getInt(3)
						+ "\t" + resultSet.getString(4));
			}
		}
	}

	public static void insertRecord() throws SQLException {
		String name = null;
		Integer age = null;
		String address = null;

		if (con != null) {
			statement = con.prepareStatement("INSERT INTO students (name,age,address) VALUES(?,?,?)");
			try (Scanner scanner = new Scanner(System.in)) {
				System.out.print("Enter student name: ");
				name = scanner.next();
				System.out.print("Enter student age: ");
				age = scanner.nextInt();
				System.out.print("Enter student address: ");
				address = scanner.next();
			}
		}
		if (statement != null) {
			statement.setString(1, name);
			statement.setInt(2, age);
			statement.setString(3, address);
			int rowsAffected = statement.executeUpdate();

			if (rowsAffected != 0) {
				System.out.println("Student record successfully inserted with no. of rows inserted: " + rowsAffected);
			} else
				System.out.println("Student record failed to insert with no. of rows inserted: " + rowsAffected);
		}
	}

	public static void updateRecord() throws SQLException {
		Integer id = null;
		Integer age = null;

		if (con != null) {
			statement = con.prepareStatement("UPDATE students SET age=? WHERE id=?");
			try (Scanner scanner = new Scanner(System.in)) {
				System.out.print("Enter student id: ");
				id = scanner.nextInt();
				System.out.print("Enter student age: ");
				age = scanner.nextInt();
			}
		}
		if (statement != null) {
			statement.setInt(1, age);
			statement.setInt(2, id);

			int rowsAffected = statement.executeUpdate();

			if (rowsAffected != 0) {
				System.out.println("Student record successfully updated with no. of rows affected: " + rowsAffected);
			} else
				System.out.println("Student record failed to update with no. of rows affected: " + rowsAffected);
		}
	}

	public static void deleteRecord() throws SQLException {
		Integer id = null;

		if (con != null) {
			statement = con.prepareStatement("DELETE FROM students WHERE id=?");
			try (Scanner scanner = new Scanner(System.in)) {
				System.out.print("Enter student id: ");
				id = scanner.nextInt();
			}
		}
		if (statement != null) {
			statement.setInt(1, id);

			int rowsAffected = statement.executeUpdate();

			if (rowsAffected != 0) {
				System.out.println("Student record successfully deleted with no. of rows affected: " + rowsAffected);
			} else
				System.out.println("Student record failed to delete with no. of rows affected: " + rowsAffected);
		}
	}
}
