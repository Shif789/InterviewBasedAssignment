package in.ineuron.entity;

public class Child extends Parent {

	public Child(String name, String message) {
		super(name, message);
		System.out.println(message + " " + name + ", This is from Child class");
	}

	
}
