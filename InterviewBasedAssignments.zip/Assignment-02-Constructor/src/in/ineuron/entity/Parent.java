package in.ineuron.entity;

public class Parent {

	private String name;
	private String message;

	public Parent(String name, String message) {
		this.name = name;
		this.message = message;
		System.out.println(message + " " + name + ", This is from Parent class");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
