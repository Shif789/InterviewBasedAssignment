package in.ineuron;

import in.ineuron.entity.Child;

public class MainApp {

	public static void main(String[] args) {
		String name="Shifat";
		String message="Good Day";
		
		// creating instance of child class
		new Child(name, message);

		/* key points about constructors
		 1.By default jvm supplies zero argument constructor if no constructor is explicitly written in the class
		 2.Constructor is a special method to create instance of a class
		 3.If parameterized constructor is written then jvm will not provide zero argument constructor and it has to be explicitly written if needed
		 4.Constructor has the same name of the class and it doesn't have any return type
		 5.Contructors can be overloaded and can be public or private
		 6.Constructors doesn't get inherited but it has to be called using super() keyword from the child constructor
		 7."this()" keyword is used for child child constructor and "super()" is used for parent constructor
		 */
	}

}
