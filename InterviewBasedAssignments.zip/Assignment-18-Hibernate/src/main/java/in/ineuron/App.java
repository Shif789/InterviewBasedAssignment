package in.ineuron;

import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import in.ineuron.model.Student;
import in.ineuron.util.HibernateUtil;

public class App {
	private static Session session = null;
	private static Integer id = null;

	public static void main(String[] args) {
		try {
			if (session == null) {
				session = HibernateUtil.getSession();

				searchOperation();

			}
		} catch (HibernateException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			// closing resources
			HibernateUtil.closeSession();
			HibernateUtil.closeSessionFactory();
		}
	}

	public static void searchOperation() {
		if (session != null) {
			Scanner scanner = new Scanner(System.in);
			System.out.print("Enter the student id: ");
			id = scanner.nextInt();
			Student student = session.get(Student.class, id);

			if (student != null)
				System.out.println(student);
			else
				System.out.println("Student record not found with id: " + id);

			scanner.close();
		}
	}
}
