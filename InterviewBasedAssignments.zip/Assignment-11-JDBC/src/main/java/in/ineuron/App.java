package in.ineuron;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import in.ineuron.util.JdbcUtil;

public class App {
	public static void main(String[] args) {
		Connection con = null;
		Statement statement = null;
		ResultSet resultSet = null;
		// Creating object of class implementing com.zaxxer.hikari.HikariDataSource;
		try {
			// creating connection object using DataSource object
			con = JdbcUtil.getJdbcConnection();
			System.out.println(con.getClass().getName());
			if (con != null) {
				statement = con.createStatement();
			}
			if (statement != null) {
				resultSet = statement.executeQuery("SELECT id,name,age,address FROM students");
			}
			if (resultSet != null) {
				System.out.println("Id\tName\tAge\tAddress");
				while (resultSet.next()) {
					System.out.println(resultSet.getInt(1) + "\t" + resultSet.getString(2) + "\t" + resultSet.getInt(3)
							+ "\t" + resultSet.getString(4));
				}
			}
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				JdbcUtil.cleanUp(con, statement, resultSet);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
