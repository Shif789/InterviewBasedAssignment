package in.ineuron;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Scanner;

import in.ineuron.util.JdbcUtil;

public class App {
	public static void main(String[] args) {
		// Resources used
        Connection con = null;
        PreparedStatement preparedStatement = null;
        Scanner scanner = null;

        // variable used
        String eName = null;
        int eAge = 0;
        int id = 0;
        String eAddress = null;

        try {
            // Establish the connection where loading will be automatic
            con = JdbcUtil.getJdbcConnection();
            // insert query with place holders
            String insertQuery = "INSERT INTO employees(id,name, age, address) VALUES(?,?,?,?)";

            // create prepared statement
            if (con != null)
                preparedStatement = con.prepareStatement(insertQuery);

            if (preparedStatement != null) {
                // take the inputs from user
                scanner = new Scanner(System.in);
                if (scanner != null) {
                    while (true) {
                    	System.out.print("Enter the employee id: ");
                    	id = scanner.nextInt(); 
                        System.out.print("Enter the employee name: ");
                        eName = scanner.next(); // for mutilple string value with space
                        System.out.print("Enter the employee age: ");
                        eAge = scanner.nextInt();// for single string value
                        System.out.print("Enter the employee address: ");
                        eAddress = scanner.next();// for single string value

                        // set the values
                        preparedStatement.setInt(1, id);
                        preparedStatement.setString(2, eName);
                        preparedStatement.setInt(3, eAge);
                        preparedStatement.setString(4, eAddress);

                        // Query added to the batch file
                        preparedStatement.addBatch();

                        // asking user to continue the loop or end
                        System.out.print("Do you want to insert one more record [Yes or No]: ");
                        String option = scanner.next();

                        if (option.equalsIgnoreCase("no")) {
                            break;
                        }
                    }
                }

                // executing the queries present in the batch file
                int[] noRowsAffected = preparedStatement.executeBatch();

                // Display the result
                System.out.println("No. of rows affected: " + Arrays.toString(noRowsAffected));

            }

        } catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				JdbcUtil.cleanUp(con, preparedStatement, null);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
