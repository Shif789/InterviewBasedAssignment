package in.ineuron.service;

import in.ineuron.model.Course;

public interface ICourseService {

	String insertCourse(Course course);
}
