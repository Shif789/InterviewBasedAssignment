package in.ineuron.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.dao.ICourseRepository;
import in.ineuron.model.Course;

@Service
public class CourseServiceImpl implements ICourseService {

	@Autowired // auto-wiring the implementing class object of ICourseRepository
	private ICourseRepository repository;

	
	@Override
	public String insertCourse(Course course) {
		Course savedCourse = null;
		savedCourse = repository.save(course);

		return savedCourse != null ? "Course saved with id: " + savedCourse.getCid() : "Course insertion failed";
	}

}
