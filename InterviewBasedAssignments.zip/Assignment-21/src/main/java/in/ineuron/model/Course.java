package in.ineuron.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Data
@NoArgsConstructor
@RequiredArgsConstructor
@Entity // to map entity to table
@Table(name = "courses")
public class Course {

	@Id // to consider it as primary key
	@GeneratedValue(strategy = GenerationType.IDENTITY) // for auto generation and incrementation
	private Integer cid;

	@NonNull
	private String cname;

	@NonNull
	private Integer cprice;
}
