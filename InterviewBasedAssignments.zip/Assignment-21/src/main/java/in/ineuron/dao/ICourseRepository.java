package in.ineuron.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ineuron.model.Course;

public interface ICourseRepository extends JpaRepository<Course, Integer> {

}
