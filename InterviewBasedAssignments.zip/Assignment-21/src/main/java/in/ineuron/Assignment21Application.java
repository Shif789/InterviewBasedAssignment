package in.ineuron;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

import in.ineuron.model.Course;
import in.ineuron.service.ICourseService;

@SpringBootApplication
public class Assignment21Application {

	public static void main(String[] args) {
		ApplicationContext applicationContext = SpringApplication.run(Assignment21Application.class, args);

		// Scanner object for reading user inputs
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter Course Name: ");
		String name = scanner.next();

		System.out.print("Enter Course Price: ");
		int price = scanner.nextInt();

		// creating a pojo object course
		Course course = new Course(name, price);

		// getting the course service class object
		ICourseService service = applicationContext.getBean(ICourseService.class);

		// calling the insert method from service object
		String insertStatus = service.insertCourse(course);

		// printing the insert status
		System.out.println(insertStatus);

		// closing resources
		scanner.close();
		// closing the applicaton context
		((ConfigurableApplicationContext) applicationContext).close();
	}

}
