package in.ineuron.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ineuron.model.UserProfile;

public interface IUserRepository extends JpaRepository<UserProfile, String> {

	public UserProfile findByUserNameAndPassword(String userName, String password);
}
