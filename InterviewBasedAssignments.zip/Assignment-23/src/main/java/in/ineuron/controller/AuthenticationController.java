package in.ineuron.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import in.ineuron.dao.IUserRepository;
import in.ineuron.model.UserProfile;

@Controller
public class AuthenticationController {

	@Autowired
	private IUserRepository repository;

	@GetMapping(value = "/")
	public String showRegistrationPage() {
		return "registration";
	}

	@PostMapping(value = "/register")
	public String register(@ModelAttribute UserProfile userProfile, Map<String, Object> model) {
		System.out.println(userProfile);
		UserProfile savedUserProfile = repository.save(userProfile);

		if (savedUserProfile != null)
			model.put("status", "Successfully Registered...");
		else
			model.put("status", "Resgistration failed...");

		return "registration";
	}

	@GetMapping(value = "/showLogin")
	public String showLoginPage() {
		return "login";
	}

	@PostMapping(value = "/login")
	public String login(@RequestParam String userName, @RequestParam String password, Map<String, Object> model) {
		System.out.println(userName + ": " + password);
		try {

			UserProfile userProfile = repository.findByUserNameAndPassword(userName, password);
			if (userProfile != null) {

				model.put("status", "Login Successful...");
				return "home";
//			if(userName.equals(userProfile.getUserName()) && password.equals(userProfile.getPassword())) {
//				model.put("status", "Login Successful...");
//				return "home";
//			}
			} else
				model.put("status", "Login Failure....\nEnter valid username and password!");
			return "login";

		} catch (Exception e) {
			e.printStackTrace();
			model.put("status", "Login Failure....\nEnter valid username and password!");
			return "login";
		}
	}

}
