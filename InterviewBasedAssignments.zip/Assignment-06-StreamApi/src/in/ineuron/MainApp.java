package in.ineuron;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MainApp {

	public static void main(String[] args) {

		List<Integer> list = Arrays.asList(10, 5, 11, 8, 6, 1, 7, 9, 12, 13, 2);

		List<Integer> filteredList = list
				.stream()// to perform stream operation
				.filter(i -> i % 2 == 0) // filtered to get the even numbers
				.map(i -> i * 2).sorted() // mapped to double every number
				.collect(Collectors.toList()); //collected in a list variable
		
		filteredList.forEach(System.out::println);// to print the filtered list values
	}
}
