package in.ineuron.restcontroller;

import java.util.Random;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@RestController
@RequestMapping("/api/test")
public class CircuitBreakerController {

	@GetMapping(value = "/hello")
	@HystrixCommand(fallbackMethod = "showFallBack")
	public ResponseEntity<String> sayHello() {

		// generating dummy exception
		if (new Random().nextInt(10) <= 100)
			throw new RuntimeException("Dummy");

		return new ResponseEntity<String>("No errors, working fine!", HttpStatus.OK);
	}

	public ResponseEntity<String> showFallBack() {
		return new ResponseEntity<String>("From Fallback Method: there are errors!", HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
