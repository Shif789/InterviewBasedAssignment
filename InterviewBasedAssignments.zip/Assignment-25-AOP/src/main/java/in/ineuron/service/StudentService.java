package in.ineuron.service;

import org.springframework.stereotype.Service;

@Service
public class StudentService {

	public void saveStudent() {
		System.out.println("\nStudent record successfully saved...\n");
	}
}
