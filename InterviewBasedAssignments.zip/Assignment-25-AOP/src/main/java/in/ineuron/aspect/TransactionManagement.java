package in.ineuron.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class TransactionManagement {

	@Pointcut(value = "execution(public * in.ineuron.service.*.*())")
	public void pointCut() {

	}

	@Before(value = "pointCut()")
	public void beginTransaction() {
		System.out.println("Transaction began");
	}

	@AfterReturning(value = "pointCut()")
	public void commitTransaction() {
		System.out.println("Transaction committed");
	}

	@AfterThrowing(value = "pointCut()", throwing = "obj") // JoinPoint
	public void rollBack(Throwable obj) {
		System.out.println("Transaction rollbacked...." + obj.getMessage());
	}

	@After("pointCut()") // JoinPoint
	public void emailSetupCredentials() {
		System.out.println("Email setup is done....");
	}
}
