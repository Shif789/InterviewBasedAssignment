package in.ineuron;

import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import in.ineuron.model.Student;
import in.ineuron.util.HibernateUtil;

public class App {
	private static Session session = null;
	private static Transaction transaction = null;
	private static boolean flag = false;
	private static Integer id = null;

	public static void main(String[] args) {
		int option = 0;
		try {
			if (session == null) {
				session = HibernateUtil.getSession();

				Scanner scan = new Scanner(System.in);
				System.out.println("Press 1 for save operation/n Press 2 for search operation: ");
				option = scan.nextInt();

				if (option == 1)
					saveOperation();
				else if (option == 2)
					searchOperation();
				else
					System.out.println("Enter a valid number from the option given!");
				
				scan.close();
			}
		} catch (HibernateException e) {
			e.printStackTrace();
			flag = false;
		} catch (Exception e) {
			e.printStackTrace();
			flag = false;
		} finally {
			if (option == 1)
				transactionActivites();

			// closing resources
			HibernateUtil.closeSession();
			HibernateUtil.closeSessionFactory();
		}
	}

	public static void saveOperation() {
		if (session != null) {
			transaction = session.beginTransaction();

			Scanner scanner = new Scanner(System.in);
			System.out.println("Enter the student name: ");
			String name = scanner.next();
			System.out.println("Enter the student address: ");
			String address = scanner.next();
			System.out.println("Enter the student age: ");
			Integer age = scanner.nextInt();

			if (transaction != null) {
				Student student = new Student(name, age, address);
				id = (Integer) session.save(student);
				flag = true;
			}

			scanner.close();
		}
	}

	public static void transactionActivites() {
		if (flag) {
			transaction.commit();
			System.out.println("Student record saved to database with id: " + id);
		} else {
			transaction.rollback();
			System.out.println("Student record failed to save to database with id: " + id);
		}
	}

	public static void searchOperation() {
		if (session != null) {
			Scanner scanner = new Scanner(System.in);
			System.out.println("Enter the student id: ");
			id = scanner.nextInt();
			Student student = session.get(Student.class, id);

			if (student != null)
				System.out.println(student);
			else
				System.out.println("Student record not found with id: " + id);

			scanner.close();
		}
	}
}
