package in.ineuron;

import java.util.Scanner;

import in.ineuron.entity.Test;

public class MainApp {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter number: ");
		Integer number = scanner.nextInt();
		Test test = new Test(number);

		// exception handling logic
		try {
			System.out.println(test.checkNumber());
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("Negative number will give runtime exception");
			// closing resources
			scanner.close();
		}

		System.out.println("End of program!...");
	}

}
