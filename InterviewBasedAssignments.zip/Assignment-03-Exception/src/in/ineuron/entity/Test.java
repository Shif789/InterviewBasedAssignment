package in.ineuron.entity;

public class Test {
	private Integer number;

	public Test() {
		System.out.println("Zero Parameterized Constructor...");
	}

	public Test(Integer number) {
		this.number = number;
	}
	
	public String checkNumber() {
		
		if (number<0) {
			// exception raised
			throw new IllegalArgumentException("Number entered "+number+" is negative");
		}
		
		return "Number entered "+number+" is positive";
	}

}
