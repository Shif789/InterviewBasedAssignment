package in.ineuron;

public class App {
	public static void main(String[] args) {

		Q q = new Q();
        new Producer(q);
        new Consumer(q);
	}
}
