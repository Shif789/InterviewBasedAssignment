package in.ineuron;

public class Producer extends Thread {

	Q q;

    public Producer(Q q) {
        this.q = q;
        Thread t = new Thread(this, "Thread Producer");
        t.start();
    }

    @Override
    public void run() {
        int i = 0;
        for (int j=0;j<10;j++) {
            q.setNum(i++);
            try {
                Thread.sleep(1000);
            } catch (Exception e) {
            }
        }
    }
}
