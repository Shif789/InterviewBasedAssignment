package in.ineuron;

public class Consumer extends Thread {

	Q q;

	public Consumer(Q q) {
		this.q = q;
		Thread t = new Thread(this, "Thread Consumer");
		t.start();
	}

	@Override
	public void run() {
		for (int j=0;j<10;j++) {
			q.getNum();
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
			}
		}
	}
}
