package in.ineuron;

public class Q {

	int num;
	boolean valueSet = false;

	public synchronized void getNum() {
		while (!valueSet) {
			try {
				wait();
			} catch (Exception e) {
			}
		}
		System.out.println("Get num: " + num);
		valueSet = false;
		notify();
	}

	public synchronized void setNum(int num) {
		while (valueSet) {
			try {
				wait();
			} catch (Exception e) {
			}
		}
		System.out.println("Set num: " + num);
		this.num = num;
		valueSet = true;
		notify();
	}
}
