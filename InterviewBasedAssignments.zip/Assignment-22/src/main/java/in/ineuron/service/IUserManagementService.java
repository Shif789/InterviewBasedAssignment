package in.ineuron.service;

import java.util.List;

import in.ineuron.model.Order;
import in.ineuron.model.User;

public interface IUserManagementService {

	public String insertRecordByUser(User user);

	public String insertRecordByOrder(List<Order> orders);

	public User fetchRecordByUserId(Integer userId);

	public Order fetchRecordByOrderId(Integer orderId);
	
	public List<User> fetchAllUsers();
}
