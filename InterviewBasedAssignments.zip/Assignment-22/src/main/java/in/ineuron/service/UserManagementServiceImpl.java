package in.ineuron.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.dao.IOrderRepository;
import in.ineuron.dao.IUserRepository;
import in.ineuron.model.Order;
import in.ineuron.model.User;

@Service
public class UserManagementServiceImpl implements IUserManagementService {

	@Autowired
	private IUserRepository userRepository;

	@Autowired
	private IOrderRepository orderRepository;

	@Override
	public String insertRecordByUser(User user) {
		User savedUser = null;
		savedUser = userRepository.save(user);

		return savedUser != null ? "User record saved with id: " + savedUser.getUid() : "User record failed to save";
	}

	@Override
	public String insertRecordByOrder(List<Order> orders) {
		for (Order order : orders) {
			orderRepository.save(order);
		}
		return "Number of orders saved: " + orders.size();
	}

	@Override
	public User fetchRecordByUserId(Integer userId) {
		Optional<User> optional = userRepository.findById(userId);
		if (optional.isPresent())
			return optional.get();

		return null;
	}

	@Override
	public Order fetchRecordByOrderId(Integer orderId) {
		 Optional<Order> optional = orderRepository.findById(orderId);
		if (optional.isPresent())
			return optional.get();
		
		return null;
	}

	@Override
	public List<User> fetchAllUsers() {
		
		return userRepository.findAll();
	}

}
