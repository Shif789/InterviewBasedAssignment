package in.ineuron.runner;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import in.ineuron.model.Order;
import in.ineuron.model.User;
import in.ineuron.service.IUserManagementService;

@Component
public class TestRunner implements CommandLineRunner {

	@Autowired
	private IUserManagementService service;

	@Override
	public void run(String... args) throws Exception {
		Scanner scanner = new Scanner(System.in);
		System.out.println(
				"Press 1 for Inserting User record: \nPress 2 for Inserting Order record: \nPress 3 for Searching record by user id: \nPress 4 for Searching record by order id: \nPress 5 for Searching all records: ");
		int operation = scanner.nextInt();

		switch (operation) {
		case 1:
			insertOperationByUser();
			break;
		case 2:
			insertOperationByOrder();
			break;
		case 3:
			System.out.println("Enter user id: ");
			int userId = scanner.nextInt();
			searchByUserId(userId);
			break;
		case 4:
			System.out.println("Enter order id: ");
			int orderId = scanner.nextInt();
			searchByOrderId(orderId);
			break;

		case 5:
			searchAllUsers();
			break;

		default:
			System.out.println("Enter a valid number from the choice given...");
			break;
		}

		scanner.close();
	}

	public void insertOperationByUser() {

		// creation of parent
		User user = new User("Shifat");

		// creation of child
		Order order1 = new Order("fossil", 25000.50, 3);
		Order order2 = new Order("tissot", 35000.50, 2);
		Order order3 = new Order("swiss", 55000.50, 1);

		List<Order> orderList = Arrays.asList(order1, order2, order3);

		// injecting parent in child
		order1.setUser(user);
		order2.setUser(user);
		order3.setUser(user);

		// injecting children to parent
		user.setOrders(orderList);

		String insertStatus = service.insertRecordByUser(user);
		System.out.println(insertStatus);

	}

	public void insertOperationByOrder() {

		// creation of parent
		User user = new User("Nadim");

		// creation of child
		Order order1 = new Order("casio", 25000.50, 3);
		Order order2 = new Order("armani", 35000.50, 2);

		List<Order> orderList = Arrays.asList(order1, order2);

		// injecting parent in child
		order1.setUser(user);
		order2.setUser(user);

		// injecting children to parent
		user.setOrders(orderList);

		String insertStatus = service.insertRecordByOrder(orderList);
		System.out.println(insertStatus);

	}

	public void searchByUserId(Integer id) {
		User recordByUserId = service.fetchRecordByUserId(id);
		if (recordByUserId != null) {
			System.out.println(recordByUserId);
			System.out.println();
			System.out.println("List of Orders:");
			recordByUserId.getOrders().forEach(order -> {
				System.out.println(order);
			});
		} else
			System.out.println("Record not found with order id: " + id);

	}

	public void searchByOrderId(Integer id) {
		Order recordByOrderId = service.fetchRecordByOrderId(id);
		if (recordByOrderId != null) {
			System.out.println(recordByOrderId);
			System.out.println();
			System.out.println("Order given by user: " + recordByOrderId.getUser());
		} else
			System.out.println("Record not found with user id: " + id);

	}

	public void searchAllUsers() {
		List<User> allUsers = service.fetchAllUsers();

		allUsers.forEach(user -> {
			System.out.println(user);
			System.out.println("List of Orders:");
			user.getOrders().forEach(order -> {
				System.out.println(order);
			});
			System.out.println();
		});
	}

}
