package in.ineuron;

import java.util.Arrays;
import java.util.Scanner;

public class BinarySearch {
	public static void main(String[] args) {
		int[] arr = { 50, 30, 70, 20, 10, 80, 40, 60, 100, 90 };
		Arrays.sort(arr);// sorting the array

		boolean flag = false;

		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the number to search: ");
		int key = scanner.nextInt();

		int min = 0, max = arr.length - 1;

		for (int i = 0; i < arr.length; i++) {
			int mid = (min + max) / 2;
			if (key == arr[mid]) {
				System.out.println("key is found at index: " + mid);
				flag = true;
				break;
			} else if (key < arr[mid]) {
				max = mid - 1; // 1 is reduced in order to prevent the mid value from using again
				// mid = (min + max) / 2;
			} else {
				min = mid + 1;
				// mid = (min + max) / 2;
			}
		}
		if (flag == false) {
			System.out.println("key not found!");
		}

		scanner.close();
	}
}
