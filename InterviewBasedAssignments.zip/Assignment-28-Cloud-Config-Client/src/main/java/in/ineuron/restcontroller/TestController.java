package in.ineuron.restcontroller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import in.ineuron.dao.IStudentRepository;
import in.ineuron.model.Student;

@RestController
public class TestController {

	@Value("${spring.datasource.url:Server not working}")
	private String url;
	
	@Autowired
	private IStudentRepository repository;
	
	@GetMapping(value = "/hello")
	public String sayHello() {
		return url;
	}
	
	@GetMapping(value = "/find/{id}")
	public ResponseEntity<?> getStudentById(@PathVariable Integer id) {
		Optional<Student> optional = repository.findById(id);
		if (optional.isPresent())
			return new ResponseEntity<Student>(optional.get(), HttpStatus.OK);

		return new ResponseEntity<String>("Student record not found with id: " + id, HttpStatus.NOT_FOUND);
	}
}
