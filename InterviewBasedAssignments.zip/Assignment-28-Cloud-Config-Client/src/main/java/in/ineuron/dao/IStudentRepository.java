package in.ineuron.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import in.ineuron.model.Student;

public interface IStudentRepository extends JpaRepository<Student, Integer> {

}
