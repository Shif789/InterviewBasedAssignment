package in.ineuron.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.dao.IStudentRepository;
import in.ineuron.model.Student;

@Service
public class StudentServiceImpl implements IStudentService {

	@Autowired
	private IStudentRepository repository;

	@Override
	public String addStudent(Student student) {
		Student savedStudent = null;
		savedStudent = repository.save(student);

		return savedStudent != null ? "Student saved with id: " + savedStudent.getId() : "Student insertion failed!";
	}

}
