package in.ineuron.service;

import in.ineuron.model.Student;

public interface IStudentService {

	String addStudent(Student student);
}
