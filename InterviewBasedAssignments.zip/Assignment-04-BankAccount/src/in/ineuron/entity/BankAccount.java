package in.ineuron.entity;

public class BankAccount {

	private double totalAmount;

	public String deposit(Double amount) {
		totalAmount += amount;
		return "Amount deposited: " + amount;
	}

	public String withdraw(Double amount) {
		totalAmount -= amount;
		if (totalAmount < 0) {
			totalAmount+=amount;
			return "Account doesn't have sufficient balance, current balance is: " + totalAmount;
			
		}

		return "Amount withdrawn: " + amount;
	}

	public String checkBalance() {
		return "Amount available: " + totalAmount;
	}
}
