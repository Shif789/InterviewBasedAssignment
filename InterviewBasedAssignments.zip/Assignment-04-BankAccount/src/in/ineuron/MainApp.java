package in.ineuron;

import java.util.Scanner;

import in.ineuron.entity.BankAccount;

public class MainApp {

	public static void main(String[] args) {
		System.out.println("*******************WELCOME TO SHIFAT BANK PUBLIC LIMITED***************************\n\n");
		Scanner scanner = new Scanner(System.in);
		boolean flag = true;
		BankAccount bankAccount = new BankAccount();

		while (flag) {
			System.out.print("Press 1 to Deposit\nPress 2 to Withdaw\nPress 3 to Check-Balance: ");
			Integer option = scanner.nextInt();

			String message = null;
			Double amount = 0.0;

			switch (option) {
			case 1:
				amount = depositOperation();
				message = bankAccount.deposit(amount);
				System.out.println(message);
				break;
			case 2:
				amount = WithdrawOperation();
				message = bankAccount.withdraw(amount);
				System.out.println(message);
				break;
			case 3:

				message = bankAccount.checkBalance();
				System.out.println(message);
				break;

			default:
				System.out.println("Enter a valid number!");
				break;
			}

			System.out.print("Do you want to continue? (yes/no): ");
			String next = scanner.next();
			if ("no".equalsIgnoreCase(next))
				flag = false;

		}

		System.out.println("\n**********Thanks for using the service...*******************");
		scanner.close();
	}

	public static Double depositOperation() {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter the deposit Amount: ");
		Double depositAmount = scan.nextDouble();

		return depositAmount;
	}

	public static Double WithdrawOperation() {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter the withdrawn Amount: ");
		Double withdrawnAmount = scan.nextDouble();

		return withdrawnAmount;
	}

}
