package in.ineuron;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class App 
{
    public static void main( String[] args )
    {
        List<Integer> list = new ArrayList<>();
        boolean option=true;
        try (Scanner scanner = new Scanner(System.in)) {
        	while (option) {
				System.out.print("Enter integer value: ");
				int value = scanner.nextInt();
				list.add(value);
				
				System.out.print("Do you want to enter more numbers: (yes/no): ");
				String next = scanner.next();
				if (next.equalsIgnoreCase("no")) {
					option=false;
				}
			}
		}
        
        System.out.println(list);
        List<Integer> sorted = list.stream().sorted().collect(Collectors.toList());
        System.out.println(sorted);
        System.out.println("Second largest element:"+sorted.get(sorted.size()-1)); 
        System.out.println("Second smallest element:"+sorted.get(1)); 
    }
}
