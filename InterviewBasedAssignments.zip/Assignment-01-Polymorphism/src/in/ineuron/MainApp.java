package in.ineuron;

import in.ineuron.shape.IShape;
import in.ineuron.shape.Rectangle;
import in.ineuron.shape.Square;

public class MainApp {

	public static void main(String[] args) {
		IShape shape=null;
		Float length=10.00f;
		Float width=5.00f;
		
		 shape = new Rectangle();
		 shape.calculateArea(length, width);
		 shape.calculatePerimeter(length, width);
		 
		 shape = new Square();
		 shape.calculateArea(length, null);
		 shape.calculatePerimeter(length, null);

	}

}
