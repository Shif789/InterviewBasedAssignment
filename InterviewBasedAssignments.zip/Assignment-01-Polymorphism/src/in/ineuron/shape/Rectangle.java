package in.ineuron.shape;

public class Rectangle implements IShape {

	@Override
	public void calculateArea(Float length, Float width) {
		Float area=length*width;
		System.out.println("Area of the rectangle is: "+area);
		
	}

	@Override
	public void calculatePerimeter(Float length, Float width) {
		Float perimeter=2*(length+width);
		System.out.println("Perimeter of the rectangle is: "+perimeter);
	}

}
