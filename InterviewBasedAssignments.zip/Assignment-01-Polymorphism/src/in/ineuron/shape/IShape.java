package in.ineuron.shape;

public interface IShape {

	void calculateArea(Float length, Float width);
	void calculatePerimeter(Float length, Float width);
}
