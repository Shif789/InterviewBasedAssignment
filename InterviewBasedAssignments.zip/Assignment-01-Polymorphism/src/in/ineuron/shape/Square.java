package in.ineuron.shape;

public class Square implements IShape {

	@Override
	public void calculateArea(Float length, Float width) {
		Float area=length*length;
		System.out.println("Area of the square is: "+area);
		
	}

	@Override
	public void calculatePerimeter(Float length, Float width) {
		Float perimeter=length*4;
		System.out.println("Perimeter of the square is: "+perimeter);
	}

}
