package in.ineuron.restcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ineuron.model.Student;
import in.ineuron.service.IStudentService;

@RestController
@RequestMapping("/api/student")
public class StudentRestController {

	@Autowired
	private IStudentService service;

	@GetMapping(value = "/findAll/{pageNo}/{pageSize}/{asc}/{properties}")
	public ResponseEntity<?> searchAllStudents(@PathVariable Integer pageNo, @PathVariable Integer pageSize,
			@PathVariable Boolean asc, @PathVariable String... properties) {
		List<Student> allStudents = service.fetchAllStudentsByPageNo(pageNo, pageSize, asc, properties);

		return new ResponseEntity<>(allStudents != null ? allStudents : "Student Table is empty", HttpStatus.OK);
	}
}
