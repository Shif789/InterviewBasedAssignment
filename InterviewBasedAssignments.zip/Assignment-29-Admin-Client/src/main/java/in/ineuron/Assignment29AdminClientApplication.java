package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment29AdminClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(Assignment29AdminClientApplication.class, args);
	}

}
