package in.ineuron.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import in.ineuron.dao.IStudentRepository;
import in.ineuron.model.Student;

@Service
public class StudentServiceImpl implements IStudentService {

	@Autowired
	private IStudentRepository repository;

	@Override
	public List<Student> fetchAllStudentsByPageNo(int pageNo, int pageSize, boolean asc, String... properties) {
		Pageable pageRequest = PageRequest.of(pageNo, pageSize, asc ? Direction.ASC : Direction.DESC, properties);

		Page<Student> page = repository.findAll(pageRequest);
		
		return page != null ? page.getContent() : null;
	}

}
