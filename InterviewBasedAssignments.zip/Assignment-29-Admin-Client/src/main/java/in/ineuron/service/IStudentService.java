package in.ineuron.service;

import java.util.List;

import in.ineuron.model.Student;

public interface IStudentService {

	List<Student> fetchAllStudentsByPageNo(int pageNo, int pageSize,boolean asc, String... properties);
}
