package in.ineuron.dao;

import org.springframework.data.repository.PagingAndSortingRepository;

import in.ineuron.model.Student;

public interface IStudentRepository extends PagingAndSortingRepository<Student, Integer> {

}
